/*
 *  FloatToText.h
 *  Precision RPN
 *
 *  Created by Justin Buchanan on 9/10/09.
 *  Copyright 2009 JustBuchanan Software. All rights reserved.
 *
 */

#import <math.h>




void DoubleToText(double value, char *stringOut, int maxLength);
