//
//  ShakeView.h
//  Go Figure
//
//  Created by Justin Buchanan on 10/30/09.
//  Copyright 2009 JustBuchanan Software. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ShakeView : UIView {

}

@end
