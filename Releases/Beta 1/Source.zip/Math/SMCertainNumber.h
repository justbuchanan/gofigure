//
//  SMCertainNumber.h
//  Precision RPN
//
//  Created by Justin Buchanan on 8/30/09.
//  Copyright 2009 JustBuchanan Software. All rights reserved.
//

#import "SMNumber.h"


@interface SMCertainNumber : SMNumber

@end
