//
//  main.m
//  Precision RPN
//
//  Created by Justin Buchanan on 8/16/09.
//  Copyright JustBuchanan Software 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"Precision_RPNAppDelegate");
    [pool release];
    return retVal;
}
